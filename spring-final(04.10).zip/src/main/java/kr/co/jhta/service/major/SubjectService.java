package kr.co.jhta.service.major;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.co.jhta.vo.Subject;

@Transactional
@Service
public interface SubjectService {

	void addSubject(Subject subject);
}
