package kr.co.jhta.service.board;

public interface BoardService {

}
