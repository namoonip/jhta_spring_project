package kr.co.jhta.vo;

import java.util.Date;

public class Attendance {
	private String a_id;
	private String a_semester;
	private String a_code;
	private Date a_regdate;
	
	public String getA_id() {
		return a_id;
	}
	public String getA_semester() {
		return a_semester;
	}
	public String getA_code() {
		return a_code;
	}
	public Date getA_regdate() {
		return a_regdate;
	}
	public void setA_id(String a_id) {
		this.a_id = a_id;
	}
	public void setA_semester(String a_semester) {
		this.a_semester = a_semester;
	}
	public void setA_code(String a_code) {
		this.a_code = a_code;
	}
	public void setA_regdate(Date a_regdate) {
		this.a_regdate = a_regdate;
	}
	
}
