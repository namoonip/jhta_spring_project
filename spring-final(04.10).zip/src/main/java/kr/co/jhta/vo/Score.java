package kr.co.jhta.vo;

public class Score {
	private String s_id;
	private String s_semester;
	private String s_code;
	private String s_title;
	private String s_ispass;
	private int s_credit;
	private String s_grade;
	private int s_report_score;
	private int s_attendance_score;
	private int s_midterm_score;
	private int s_endterm_score;
	public String getS_id() {
		return s_id;
	}
	public String getS_semester() {
		return s_semester;
	}
	public String getS_code() {
		return s_code;
	}
	public String getS_title() {
		return s_title;
	}
	public String getS_ispass() {
		return s_ispass;
	}
	public int getS_credit() {
		return s_credit;
	}
	public String getS_grade() {
		return s_grade;
	}
	public int getS_report_score() {
		return s_report_score;
	}
	public int getS_attendance_score() {
		return s_attendance_score;
	}
	public int getS_midterm_score() {
		return s_midterm_score;
	}
	public int getS_endterm_score() {
		return s_endterm_score;
	}
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	public void setS_semester(String s_semester) {
		this.s_semester = s_semester;
	}
	public void setS_code(String s_code) {
		this.s_code = s_code;
	}
	public void setS_title(String s_title) {
		this.s_title = s_title;
	}
	public void setS_ispass(String s_ispass) {
		this.s_ispass = s_ispass;
	}
	public void setS_credit(int s_credit) {
		this.s_credit = s_credit;
	}
	public void setS_grade(String s_grade) {
		this.s_grade = s_grade;
	}
	public void setS_report_score(int s_report_score) {
		this.s_report_score = s_report_score;
	}
	public void setS_attendance_score(int s_attendance_score) {
		this.s_attendance_score = s_attendance_score;
	}
	public void setS_midterm_score(int s_midterm_score) {
		this.s_midterm_score = s_midterm_score;
	}
	public void setS_endterm_score(int s_endterm_score) {
		this.s_endterm_score = s_endterm_score;
	}
		
}
