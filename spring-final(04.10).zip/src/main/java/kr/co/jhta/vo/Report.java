package kr.co.jhta.vo;

import java.util.Date;

public class Report {
	private String r_id;
	private String r_semester;
	private String r_code;
	private String r_type;
	private String r_title;
	private Date r_deadline;
	private Date r_regdate;
	private String r_public;
	private int r_score;
	
	public String getR_id() {
		return r_id;
	}
	public String getR_semester() {
		return r_semester;
	}
	public String getR_code() {
		return r_code;
	}
	public String getR_type() {
		return r_type;
	}
	public String getR_title() {
		return r_title;
	}
	public Date getR_deadline() {
		return r_deadline;
	}
	public Date getR_regdate() {
		return r_regdate;
	}
	public String getR_public() {
		return r_public;
	}
	public int getR_score() {
		return r_score;
	}
	public void setR_id(String r_id) {
		this.r_id = r_id;
	}
	public void setR_semester(String r_semester) {
		this.r_semester = r_semester;
	}
	public void setR_code(String r_code) {
		this.r_code = r_code;
	}
	public void setR_type(String r_type) {
		this.r_type = r_type;
	}
	public void setR_title(String r_title) {
		this.r_title = r_title;
	}
	public void setR_deadline(Date r_deadline) {
		this.r_deadline = r_deadline;
	}
	public void setR_regdate(Date r_regdate) {
		this.r_regdate = r_regdate;
	}
	public void setR_public(String r_public) {
		this.r_public = r_public;
	}
	public void setR_score(int r_score) {
		this.r_score = r_score;
	}
	
}
