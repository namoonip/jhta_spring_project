package kr.co.jhta.controller.major;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import kr.co.jhta.service.major.SemesterService;

@Controller
public class SemesterController {

	@Autowired
	private SemesterService semesterService;
	
	
}
