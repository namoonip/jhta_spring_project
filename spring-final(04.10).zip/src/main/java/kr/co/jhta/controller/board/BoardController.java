package kr.co.jhta.controller.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.jhta.service.board.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
}
