package kr.co.jhta.service.professor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.jhta.dao.professor.ProfessorDao;
import kr.co.jhta.vo.Professor;

@Service
public class ProfessorServiceImpl implements ProfessorService {

	@Autowired
	private ProfessorDao professordao;
	
	@Override
	public List<Professor> proAllList() {
		return professordao.proAllList();
	}
	
}
