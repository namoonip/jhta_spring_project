package kr.co.jhta.service.lecture;

public interface LectureService {
	
}
