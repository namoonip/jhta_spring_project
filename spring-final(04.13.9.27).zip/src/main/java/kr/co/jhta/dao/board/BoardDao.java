package kr.co.jhta.dao.board;

public interface BoardDao {

}
