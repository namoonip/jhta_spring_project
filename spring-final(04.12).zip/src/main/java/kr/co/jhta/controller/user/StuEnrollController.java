package kr.co.jhta.controller.user;

import org.springframework.stereotype.Controller;

@Controller
public class StuEnrollController {

	
}
