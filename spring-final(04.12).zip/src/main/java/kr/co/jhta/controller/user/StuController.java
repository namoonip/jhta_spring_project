package kr.co.jhta.controller.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StuController {
	
	@RequestMapping("/stuMain")
	public String stuMain() {
		return "/student/stuMain";
	}
	
	@RequestMapping("/stuInfo")
	public String stuInfo() {
		return "/student/stuInfo/stuInfo";
	}
	
	@RequestMapping("/stuEdit")
	public String stuEdit() {
		return "/student/stuInfo/stuEdit";
	}
	
}