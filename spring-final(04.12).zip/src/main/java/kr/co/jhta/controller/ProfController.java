package kr.co.jhta.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProfController {
	
	@RequestMapping("/profMain")
	public String testMain() {
		return "/prof/profMain";
	}
	
}
