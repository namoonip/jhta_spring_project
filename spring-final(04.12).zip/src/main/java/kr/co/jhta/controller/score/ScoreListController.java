package kr.co.jhta.controller.score;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.jhta.service.score.ScoreService;
import kr.co.jhta.vo.Scorelist;
import kr.co.jhta.vo.SubjectRegister;

@Controller
public class ScoreListController {
	@Autowired
	private ScoreService scoreService;
	
	@RequestMapping("/scorelist.do")
	public String scorelist(Model model){
		
		List<Scorelist> scorelist = new ArrayList<Scorelist>();
		List<SubjectRegister> srlist = scoreService.getAllSubjectList();
		for(SubjectRegister list : srlist){
			Scorelist scoreinfo = new Scorelist();
			System.out.println(list);
			scoreinfo.setR_no(list.getR_regi_no());
			scoreinfo.setSubject(scoreService.getSubjectInfo(list.getJ_no()));
			scoreinfo.setStudent(scoreService.getStudentInfo(list.getU_stu_no()));
			
			scorelist.add(scoreinfo);
		}
		System.out.println(scorelist);
		model.addAttribute("scorelist", scorelist);
		
		return "score/scorelist";
	}
		
}
