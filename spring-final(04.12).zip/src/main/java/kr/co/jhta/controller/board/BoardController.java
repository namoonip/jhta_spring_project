package kr.co.jhta.controller.board;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.jhta.service.board.BoardService;
import kr.co.jhta.vo.BoardForm;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/notice",method=RequestMethod.GET)
	public String notice(){
		return "/board/notice";
	}
	
	@RequestMapping("/board")
	public String board () {
		return "/board/board";
	}
	
	@RequestMapping("/QnABoard")
	public String QnABoard(){
		return "/board/QnABoard";
	}
	
	@RequestMapping("/mtomBoard")
	public String mtomBoard(){
		return "/board/mtomBoard";
	}
	
	@RequestMapping(value="/boardForm", method=RequestMethod.GET)
	public String boardForm(Model model){
		
		model.addAttribute("boardForm", new BoardForm());
		return "/board/boardForm";
	}
	
	@RequestMapping(value="/boardForm", method=RequestMethod.POST)
	public String addBoard(@Valid BoardForm boardForm, Errors errors){
		if (errors.hasErrors()) {
			return "/board/boardForm";
		}
		
		System.out.println(boardForm);
		
		return "redirect:/board/board";
		
	}
	
	
}
