package kr.co.jhta.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminRegisterSubjectController {
	
	@RequestMapping("/adminregsubject")
	public String adminRegSubject() {
		return "administer/adminregsubject";
	}
	
	@RequestMapping("/adminregstudent")
	public String adminRegStudent() {
		return "administer/adminregstudent";
	}
}
