package kr.co.jhta.vo;

import java.util.Date;

public class Professor {
	private int p_no;
	private String p_id;
	private String p_name;
	private String p_gender;
	private SiteMap sitemap;
	private String p_division;
	private String p_pwd;
	private String p_register;
	private String p_phone;
	private String p_addr;
	private String p_email;
	private String p_grade;
	private String p_ssn;
	private String p_forei;
	private Date p_entrydate;
	private Date p_leavedate;
	public int getP_no() {
		return p_no;
	}
	public void setP_no(int p_no) {
		this.p_no = p_no;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_gender() {
		return p_gender;
	}
	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}
	public SiteMap getSitemap() {
		return sitemap;
	}
	public void setSitemap(SiteMap sitemap) {
		this.sitemap = sitemap;
	}
	public String getP_division() {
		return p_division;
	}
	public void setP_division(String p_division) {
		this.p_division = p_division;
	}
	public String getP_pwd() {
		return p_pwd;
	}
	public void setP_pwd(String p_pwd) {
		this.p_pwd = p_pwd;
	}
	public String getP_register() {
		return p_register;
	}
	public void setP_register(String p_register) {
		this.p_register = p_register;
	}
	public String getP_phone() {
		return p_phone;
	}
	public void setP_phone(String p_phone) {
		this.p_phone = p_phone;
	}
	public String getP_addr() {
		return p_addr;
	}
	public void setP_addr(String p_addr) {
		this.p_addr = p_addr;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getP_grade() {
		return p_grade;
	}
	public void setP_grade(String p_grade) {
		this.p_grade = p_grade;
	}
	public String getP_ssn() {
		return p_ssn;
	}
	public void setP_ssn(String p_ssn) {
		this.p_ssn = p_ssn;
	}
	public String getP_forei() {
		return p_forei;
	}
	public void setP_forei(String p_forei) {
		this.p_forei = p_forei;
	}
	public Date getP_entrydate() {
		return p_entrydate;
	}
	public void setP_entrydate(Date p_entrydate) {
		this.p_entrydate = p_entrydate;
	}
	public Date getP_leavedate() {
		return p_leavedate;
	}
	public void setP_leavedate(Date p_leavedate) {
		this.p_leavedate = p_leavedate;
	}
	
	
}
