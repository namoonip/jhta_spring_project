package kr.co.jhta.vo;

import java.util.Date;

public class SubjectRegister {
	
	private int r_regi_no;
	private int u_stu_no;
	private int j_no;
	private int r_grade;
	private int r_maxgrade;

	public int getR_regi_no() {
		return r_regi_no;
	}
	public int getU_stu_no() {
		return u_stu_no;
	}
	public int getJ_no() {
		return j_no;
	}
	public int getR_grade() {
		return r_grade;
	}
	public int getR_maxgrade() {
		return r_maxgrade;
	}
	public void setR_regi_no(int r_regi_no) {
		this.r_regi_no = r_regi_no;
	}
	public void setU_stu_no(int u_stu_no) {
		this.u_stu_no = u_stu_no;
	}
	public void setJ_no(int j_no) {
		this.j_no = j_no;
	}
	public void setR_grade(int r_grade) {
		this.r_grade = r_grade;
	}
	public void setR_maxgrade(int r_maxgrade) {
		this.r_maxgrade = r_maxgrade;
	}
	
	@Override
	public String toString() {
		return "SubjectRegister [r_regi_no=" + r_regi_no + ", u_stu_no=" + u_stu_no + ", j_no=" + j_no + ", r_grade="
				+ r_grade + ", r_maxgrade=" + r_maxgrade + "]";
	}
	
}
