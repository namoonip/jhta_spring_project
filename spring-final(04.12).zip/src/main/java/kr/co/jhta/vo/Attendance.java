package kr.co.jhta.vo;

import java.util.Date;

public class Attendance {
	private int a_att_no;
	private int s_score_no;
	private int a_count;
	private Date a_score;
	
	public int getA_att_no() {
		return a_att_no;
	}
	public int getS_score_no() {
		return s_score_no;
	}
	public int getA_count() {
		return a_count;
	}
	public Date getA_score() {
		return a_score;
	}
	public void setA_att_no(int a_att_no) {
		this.a_att_no = a_att_no;
	}
	public void setS_score_no(int s_score_no) {
		this.s_score_no = s_score_no;
	}
	public void setA_count(int a_count) {
		this.a_count = a_count;
	}
	public void setA_score(Date a_score) {
		this.a_score = a_score;
	}		
}
