package kr.co.jhta.vo;

import java.util.Date;

public class Syllabus {
	private int s_no;
	private Subject subject;
	private String s_sub_name;
	private int s_midtrum;
	private int s_final;
	private int s_atlen;
	private int s_project;
	private String s_distri;
	private String s_outline;
	private String s_goals;
	private String s_method;
	private Professor professor;
	private String s_name;
	private String s_email;
	private String s_phone;
	private String s_book;
	private Date s_mid_st;
	private Date s_mid_end;
	private Date s_final_st;
	private Date s_final_end;
	private Date s_pro_st;
	private Date s_pro_end;
	private String s_pro_content;
	private String s_1week;
	private String s_2week;
	private String s_3week;
	private String s_4week;
	private String s_5week;
	private String s_6week;
	private String s_7week;
	private String s_8week;
	private String s_9week;
	private String s_10week;
	private String s_11week;
	private String s_12week;
	private String s_13week;
	private String s_14week;
	private String s_15week;
	public int getS_no() {
		return s_no;
	}
	public void setS_no(int s_no) {
		this.s_no = s_no;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public String getS_sub_name() {
		return s_sub_name;
	}
	public void setS_sub_name(String s_sub_name) {
		this.s_sub_name = s_sub_name;
	}
	public int getS_midtrum() {
		return s_midtrum;
	}
	public void setS_midtrum(int s_midtrum) {
		this.s_midtrum = s_midtrum;
	}
	public int getS_final() {
		return s_final;
	}
	public void setS_final(int s_final) {
		this.s_final = s_final;
	}
	public int getS_atlen() {
		return s_atlen;
	}
	public void setS_atlen(int s_atlen) {
		this.s_atlen = s_atlen;
	}
	public int getS_project() {
		return s_project;
	}
	public void setS_project(int s_project) {
		this.s_project = s_project;
	}
	public String getS_distri() {
		return s_distri;
	}
	public void setS_distri(String s_distri) {
		this.s_distri = s_distri;
	}
	public String getS_outline() {
		return s_outline;
	}
	public void setS_outline(String s_outline) {
		this.s_outline = s_outline;
	}
	public String getS_goals() {
		return s_goals;
	}
	public void setS_goals(String s_goals) {
		this.s_goals = s_goals;
	}
	public String getS_method() {
		return s_method;
	}
	public void setS_method(String s_method) {
		this.s_method = s_method;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getS_email() {
		return s_email;
	}
	public void setS_email(String s_email) {
		this.s_email = s_email;
	}
	public String getS_phone() {
		return s_phone;
	}
	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}
	public String getS_book() {
		return s_book;
	}
	public void setS_book(String s_book) {
		this.s_book = s_book;
	}
	public Date getS_mid_st() {
		return s_mid_st;
	}
	public void setS_mid_st(Date s_mid_st) {
		this.s_mid_st = s_mid_st;
	}
	public Date getS_mid_end() {
		return s_mid_end;
	}
	public void setS_mid_end(Date s_mid_end) {
		this.s_mid_end = s_mid_end;
	}
	public Date getS_final_st() {
		return s_final_st;
	}
	public void setS_final_st(Date s_final_st) {
		this.s_final_st = s_final_st;
	}
	public Date getS_final_end() {
		return s_final_end;
	}
	public void setS_final_end(Date s_final_end) {
		this.s_final_end = s_final_end;
	}
	public Date getS_pro_st() {
		return s_pro_st;
	}
	public void setS_pro_st(Date s_pro_st) {
		this.s_pro_st = s_pro_st;
	}
	public Date getS_pro_end() {
		return s_pro_end;
	}
	public void setS_pro_end(Date s_pro_end) {
		this.s_pro_end = s_pro_end;
	}
	public String getS_pro_content() {
		return s_pro_content;
	}
	public void setS_pro_content(String s_pro_content) {
		this.s_pro_content = s_pro_content;
	}
	public String getS_1week() {
		return s_1week;
	}
	public void setS_1week(String s_1week) {
		this.s_1week = s_1week;
	}
	public String getS_2week() {
		return s_2week;
	}
	public void setS_2week(String s_2week) {
		this.s_2week = s_2week;
	}
	public String getS_3week() {
		return s_3week;
	}
	public void setS_3week(String s_3week) {
		this.s_3week = s_3week;
	}
	public String getS_4week() {
		return s_4week;
	}
	public void setS_4week(String s_4week) {
		this.s_4week = s_4week;
	}
	public String getS_5week() {
		return s_5week;
	}
	public void setS_5week(String s_5week) {
		this.s_5week = s_5week;
	}
	public String getS_6week() {
		return s_6week;
	}
	public void setS_6week(String s_6week) {
		this.s_6week = s_6week;
	}
	public String getS_7week() {
		return s_7week;
	}
	public void setS_7week(String s_7week) {
		this.s_7week = s_7week;
	}
	public String getS_8week() {
		return s_8week;
	}
	public void setS_8week(String s_8week) {
		this.s_8week = s_8week;
	}
	public String getS_9week() {
		return s_9week;
	}
	public void setS_9week(String s_9week) {
		this.s_9week = s_9week;
	}
	public String getS_10week() {
		return s_10week;
	}
	public void setS_10week(String s_10week) {
		this.s_10week = s_10week;
	}
	public String getS_11week() {
		return s_11week;
	}
	public void setS_11week(String s_11week) {
		this.s_11week = s_11week;
	}
	public String getS_12week() {
		return s_12week;
	}
	public void setS_12week(String s_12week) {
		this.s_12week = s_12week;
	}
	public String getS_13week() {
		return s_13week;
	}
	public void setS_13week(String s_13week) {
		this.s_13week = s_13week;
	}
	public String getS_14week() {
		return s_14week;
	}
	public void setS_14week(String s_14week) {
		this.s_14week = s_14week;
	}
	public String getS_15week() {
		return s_15week;
	}
	public void setS_15week(String s_15week) {
		this.s_15week = s_15week;
	}
	
	
}
