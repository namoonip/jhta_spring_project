package kr.co.jhta.vo;

public class Scorelist {
	
	private int r_no;
	private Student student;
	private Subject subject;
	
	public int getR_no() {
		return r_no;
	}
	public Student getStudent() {
		return student;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setR_no(int r_no) {
		this.r_no = r_no;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	
	@Override
	public String toString() {
		return "Scorelist [r_no=" + r_no + ", student=" + student + ", subject=" + subject + "]";
	}
	
}
