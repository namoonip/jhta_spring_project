package kr.co.jhta.vo;

import java.util.Date;

public class AttendanceDate {
	private int attNo;
	private Date attDate;
	
	public int getAttNo() {
		return attNo;
	}
	public Date getAttDate() {
		return attDate;
	}
	public void setAttNo(int attNo) {
		this.attNo = attNo;
	}
	public void setAttDate(Date attDate) {
		this.attDate = attDate;
	}
	
}
