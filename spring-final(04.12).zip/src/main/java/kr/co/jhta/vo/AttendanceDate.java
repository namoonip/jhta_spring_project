package kr.co.jhta.vo;

import java.util.Date;

public class AttendanceDate {
	private int a_att_no;
	private Date a_date;
	
	public int getA_att_no() {
		return a_att_no;
	}
	public Date getA_date() {
		return a_date;
	}
	public void setA_att_no(int a_att_no) {
		this.a_att_no = a_att_no;
	}
	public void setA_date(Date a_date) {
		this.a_date = a_date;
	}
		
}
