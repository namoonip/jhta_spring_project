package kr.co.jhta.vo;

public class Score {
	private int r_regi_no;
	private int s_score_no;
	private int s_credit;
	private String s_grade;
	private int s_report_score;
	private int s_attendance_score;
	private int s_midterm_score;
	private int s_endterm_score;
	
	public int getR_regi_no() {
		return r_regi_no;
	}
	public int getS_score_no() {
		return s_score_no;
	}
	public int getS_credit() {
		return s_credit;
	}
	public String getS_grade() {
		return s_grade;
	}
	public int getS_report_score() {
		return s_report_score;
	}
	public int getS_attendance_score() {
		return s_attendance_score;
	}
	public int getS_midterm_score() {
		return s_midterm_score;
	}
	public int getS_endterm_score() {
		return s_endterm_score;
	}
	public void setR_regi_no(int r_regi_no) {
		this.r_regi_no = r_regi_no;
	}
	public void setS_score_no(int s_score_no) {
		this.s_score_no = s_score_no;
	}
	public void setS_credit(int s_credit) {
		this.s_credit = s_credit;
	}
	public void setS_grade(String s_grade) {
		this.s_grade = s_grade;
	}
	public void setS_report_score(int s_report_score) {
		this.s_report_score = s_report_score;
	}
	public void setS_attendance_score(int s_attendance_score) {
		this.s_attendance_score = s_attendance_score;
	}
	public void setS_midterm_score(int s_midterm_score) {
		this.s_midterm_score = s_midterm_score;
	}
	public void setS_endterm_score(int s_endterm_score) {
		this.s_endterm_score = s_endterm_score;
	}
	
	@Override
	public String toString() {
		return "Score [r_regi_no=" + r_regi_no + ", s_score_no=" + s_score_no + ", s_credit=" + s_credit + ", s_grade="
				+ s_grade + ", s_report_score=" + s_report_score + ", s_attendance_score=" + s_attendance_score
				+ ", s_midterm_score=" + s_midterm_score + ", s_endterm_score=" + s_endterm_score + "]";
	}
}
