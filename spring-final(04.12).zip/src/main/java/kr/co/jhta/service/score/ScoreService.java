package kr.co.jhta.service.score;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.co.jhta.vo.Score;
import kr.co.jhta.vo.Student;
import kr.co.jhta.vo.Subject;
import kr.co.jhta.vo.SubjectRegister;

@Transactional
@Service
public interface ScoreService {
	List<Score> getAllScoreList();
	SubjectRegister getRegiInfo(int r_regi_no);
	List<SubjectRegister> getAllSubjectList();
	Student getStudentInfo(int u_no);
	Subject getSubjectInfo(int j_no);
}
