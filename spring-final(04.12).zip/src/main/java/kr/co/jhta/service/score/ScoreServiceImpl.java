package kr.co.jhta.service.score;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kr.co.jhta.dao.score.ScoreDao;
import kr.co.jhta.vo.Score;
import kr.co.jhta.vo.Student;
import kr.co.jhta.vo.Subject;
import kr.co.jhta.vo.SubjectRegister;

@Service
public class ScoreServiceImpl implements ScoreService{
	
	@Autowired
	private ScoreDao scoreDao;

	@Override
	public List<Score> getAllScoreList() {
		return scoreDao.getAllScoreList();
	}

	
	
	@Override
	public SubjectRegister getRegiInfo(int r_regi_no) {
		
		return scoreDao.getRegiInfo(r_regi_no);
	}
	
	//수강등록관리 리스트
	@Override
	public List<SubjectRegister> getAllSubjectList() {
		
		return scoreDao.getAllSubjectList();
	}
	
	@Override
	public Student getStudentInfo(int u_no) {
		return scoreDao.getStudentInfo(u_no);
	}

	@Override
	public Subject getSubjectInfo(int j_no) {
		return scoreDao.getSubjectinfo(j_no);
	}

	
}
