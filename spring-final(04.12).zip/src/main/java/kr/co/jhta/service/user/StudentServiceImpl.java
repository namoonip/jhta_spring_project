package kr.co.jhta.service.user;

public class StudentServiceImpl {

}
