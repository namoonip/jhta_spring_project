package kr.co.jhta.service.lecture;

import org.springframework.stereotype.Service;

@Service
public class LectureServiceImpl implements LectureService {
	
}
