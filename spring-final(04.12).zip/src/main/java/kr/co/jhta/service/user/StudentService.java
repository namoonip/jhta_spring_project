package kr.co.jhta.service.user;

public interface StudentService {

}
