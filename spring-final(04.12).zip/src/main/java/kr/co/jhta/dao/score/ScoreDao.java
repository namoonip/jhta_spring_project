package kr.co.jhta.dao.score;

import java.util.List;

import kr.co.jhta.vo.Score;
import kr.co.jhta.vo.Student;
import kr.co.jhta.vo.Subject;
import kr.co.jhta.vo.SubjectRegister;

public interface ScoreDao {
	List<Score> getAllScoreList();
	SubjectRegister getRegiInfo(int r_regi_no);
	void addScore(Score score);
	List<SubjectRegister> getAllSubjectList();
	Student getStudentInfo(int u_no);
	Subject getSubjectinfo(int j_no);
}
