package kr.co.jhta.dao.major;

import kr.co.jhta.vo.Subject;

public interface SubjectDao {

	void addSubject (Subject subject);
}
