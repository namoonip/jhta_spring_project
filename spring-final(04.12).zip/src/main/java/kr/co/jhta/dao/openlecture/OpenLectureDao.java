package kr.co.jhta.dao.openlecture;

public interface OpenLectureDao {

}
