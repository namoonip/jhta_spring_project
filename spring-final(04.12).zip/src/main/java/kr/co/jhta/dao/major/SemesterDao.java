package kr.co.jhta.dao.major;

import kr.co.jhta.vo.Semester;

public interface SemesterDao {

	void addSemester (Semester semester); 
}
