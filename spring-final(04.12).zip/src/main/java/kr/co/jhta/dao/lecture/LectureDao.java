package kr.co.jhta.dao.lecture;

public interface LectureDao {

}
